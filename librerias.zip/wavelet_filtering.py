#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 23 09:29:12 2018

@author: jfochoa
"""

import pywt
import numpy as np
import matplotlib.pyplot as plt;
import scipy.io as sio;

def wthresh(coeff,thr,s):
    y = list();
    for i in range(0,len(coeff)):
        y.append(np.multiply(coeff[i],np.abs(coeff[i])>(thr*s[i])));
    return y;
    
def thselect(signal):
    #se mide la senal en sus descomposiciones
    Num_samples = 0;
    for i in range(0,len(signal)):
        Num_samples = Num_samples + signal[i].shape[0];
    #umbral universal
    thr = np.sqrt(2*(np.log(Num_samples)))
    return thr

def wnoisest(coeff):
    #se crea el vector para las desviaciones para cada nivel
    stdc = np.zeros((len(coeff),1));
    #por cada nivel se calcula el peso
    for i in range(1,len(coeff)):
        stdc[i] = (np.median(np.absolute(coeff[i])))/0.6745;
    return stdc;