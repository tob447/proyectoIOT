"""
@author: Brayan Hoyos Madera, Universidad de Antioquia, leobahm72@gmail.com
"""

from numpy import logical_and
from numpy import argmax
from numpy import sum
from math import ceil
from math import floor
from math import log
from numpy import arange
from numpy import float32
from numpy import size
from scipy.signal.windows import dpss
from numpy import sqrt
from numpy import ones
from numpy.fft import fft
from numpy import mean
from numpy import conj
from numpy import squeeze
from numpy import real

def row_to_columns(data):
    '''
    Function that change the samles to trials if the size of samples is 1 and
    trials is different from 1.

    :param data: numpy array, required.
        Data to evaluate

    :return data: numpy array.
        Modified data.
    '''
    (samples, trials) = data.shape
    if samples == 1 and trials != 1:
        data = data.transpose()
    return data
        
def getfgrid(fs, nfft, fpass):
    '''
    Helper function that generate the frequencies axes based on limits entered
    in the parameter fpass.
    
    :param fs: int or float, required.
        sampling frequency associated with the data
    :param nfft: int or float, required.
        number of point of window.
    :param fpass: list or tuple, required.
        band of frequencies at which the fft is being calculated.

    :return f: numpy array.
        Contains the frecuens obtained from the limits in fpass.
    :return find: numpy array.
        Contain the positions where the frequencies are in the range of fpass.
    '''
    if size(fpass) != 2:
        print("fpass dimensions must be [min, max].")
        return False
    df = fs/nfft #step
    f = arange(0,fs,df, dtype = float32)
    #get positions
    find = logical_and(f >= fpass[0], f <= fpass[1])
    #get frequencies
    f = f[find == True]
    return f, find

def get_params(params):
    '''
    Function that retriever the executions parameters and asigns default values
    of data that hs not been entered.

    :param params: dict, required.
        Dict that contain the executions parameters.

    :return tapers, pad, fs, fpass, err, trialave.
    '''
    #get the params
    tapers = params.get("tapers", [])
    pad = params.get("pad", 0)
    fs = params.get("fs", 1)
    fpass = params.get("fpass", [0, fs/2])
    err = params.get("err", 0)
    trialave = params.get("trialave", 0);
        
    if tapers == [] or size(tapers) != 3:
        print('tapers unspecified, defaulting to params.tapers=[3 5]')
        tapers = [3, 5]
    else:
        #Compute timebandwidth product
        TW = tapers[1]*tapers[0]
        #Compute number of tapers
        K  = floor(2*TW - tapers[2]);
        tapers = [TW, K]
    return tapers, pad, fs, fpass, err, trialave
        
        
    
def mtspectrumc(data, params):
    '''
    Function responsible for calculating Multi-taper spectrum.

    :param data: numpy array, required.
        2-D matrix [samples, trials]. It contains the data to process.
    :param params: dict, required.
        Contained the executions parameters and necessary constants for the 
        calculations of spectrum of the input data.
        params = dict(fs = srate, fpass = [lowpass, highpass], 
                        tapers = [2, 2, 1], trialave = 1)
        
    :return s: numpy array.
        Contain the aritmetic mean of the spectral power caculated with the fft.
    :return f: numpy array.
        Contains the frecuens obtained from the limits in fpass.    
    '''
    (samples, trials) = data.shape
    tapers, pad, fs, fpass, err, trialave = get_params(params)#get params
    nfft = 2**(ceil(log(samples,2)))#calculate dimensions of window
    f, find = getfgrid(fs, nfft, fpass)#get de frequencies
    #Calculate  a matrix of tapering windows
    tapers = dpss(samples, tapers[0], tapers[1]).transpose()
    tapers = tapers*sqrt(fs)
    #Resize the data to calculate the spectrum power with fft
    (r, c) = tapers.shape
    tapers = tapers.reshape((r, c, 1))
    matrix_one = ones((samples, c, trials), dtype = float32)
    tapers = tapers * matrix_one
    data = data.reshape((samples, trials, 1))
    matrix_one = ones((samples, trials, c), dtype = float32)
    data = (data*matrix_one).transpose(0,2,1)
    data_proj = data*tapers
    #calculate the spectrum power with fft
    j = fft(data_proj, nfft, axis = 0)/fs
    #getting the values.
    j = j[find == True, :, :]
    #Eliminate the imaginary part of the data.
    s = real(mean(conj(j)*j, axis=1))

    if trialave == 1: s = squeeze(mean(s,axis=1))
    else: s = squeeze(s)
    return s, f 


def qeeg_psd_chronux(data, srate):
    '''
    Function responsible for calculating SPD distribution at specific frequency
    intervals.

    :param data: numpy array, required.
        2-D matrix [samples, trials]. It contains the data to process.
    :param srate: int or float, required.
        Data sampling frequency.

    :return cpot_d: float.
        Delta band power.
    :return cpot_a1,: float.
        Alpha 1 band power.
    :return cpot_a2: float.
        Alpha 2 band power.
    :return cpot_a: float.
        Alpha band power.
    :return cpot_b: float.
        Beta band power.
    :return cpot_d: float.
        Delta band power.
    :return cpot_g: float.
        Gamma band power.
    :return iaf_parameter: float.
   
    '''

    alpha_extended = [7, 13]
    #Config the executions parameters
    params = dict(fs = srate, fpass = [0, 50], tapers = [2, 2, 1], trialave = 1)

    #Calculate the spectral power of the data
    ss, ffo = mtspectrumc(data, params)
    #Get the positions where the values are in the alpha_extended range
    idx_alpha_extended = logical_and(ffo >= alpha_extended[0], 
                                     ffo <= alpha_extended[1])
    #Get the position where the value is maximum
    idx = argmax(ss[idx_alpha_extended==True])
    #Get the maximun value.
    value = ss[idx_alpha_extended==True][idx]
    #get the data that are in the alpha_extended range
    ff = ffo[idx_alpha_extended==True]
    #Get the value of ff where ss is maximum
    iaf_parameter = ff[idx]

    #Bands
    D = [1,4] #delta
    T = [4,8] #theta
    A1 = [8,10] #alpha1
    A2 = [10,13] #alpha2
    A = [8,13] #alpha
    B = [13,30] #beta
    G = [30,50] #gamma
    #get the data to delta
    idx_delta = logical_and(ffo >= D[0], ffo < D[1])
    #get the data to theta
    idx_theta = logical_and(ffo >= T[0], ffo < T[1])
    #get the data to alpha1
    idx_alpha1 = logical_and(ffo >= A1[0], ffo < A1[1])
    #get the data to alpha2
    idx_alpha2 = logical_and(ffo >= A2[0], ffo < A2[1])
    #get the data to alpha
    idx_alpha = logical_and(ffo >= A[0], ffo < A[1])
    #get the data to beta
    idx_beta = logical_and(ffo >= B[0], ffo < B[1])
    #get the data to gamma
    idx_gamma = logical_and(ffo >= G[0], ffo < G[1])

    #Calculate the power for each interval.
    pot_d = sum(ss[idx_delta == True])
    pot_t = sum(ss[idx_theta == True])
    pot_a1 = sum(ss[idx_alpha1 == True])
    pot_a2 = sum(ss[idx_alpha2 == True])
    pot_a = sum(ss[idx_alpha == True])
    pot_b = sum(ss[idx_beta == True])
    pot_g = sum(ss[idx_gamma == True])
    #Get the total power
    pot = sum([pot_d, pot_t, pot_a2, pot_a1, pot_b, pot_g])

    #Calculate the density power for each interval.
    cpot_d = pot_d/pot
    cpot_t = pot_t/pot
    cpot_a1 = pot_a1/pot;
    cpot_a2 = pot_a2/pot
    cpot_a =  pot_a/pot
    cpot_b = pot_b/pot
    cpot_g = pot_g/pot

    return cpot_d, cpot_t, cpot_a1, cpot_a2, cpot_a, cpot_b, cpot_g, iaf_parameter 
